(function(){
  function getHost(href){
    try{
      var u = new URL(href);
      return (u.hostname || '').replace(/^www\./,'');
    }catch(e){ return ''; }
  }

  function firstOutboundLink(card){
    var selectors = [
      "a[data-track='click'][data-btn='earn']",
      "a[data-track='click'][data-btn='claim']",
      "a[data-track='click'][data-btn='play']",
      "a[data-track='click'][data-btn='wallet']",
      "a[data-track='click'][data-btn='get']",
      "a.btn-primary",
      "a.btn"
    ];
    for (var i=0;i<selectors.length;i++){
      var a = card.querySelector(selectors[i]);
      if (a && a.getAttribute('href') && /^https?:/i.test(a.getAttribute('href'))) return a;
    }
    var links = card.querySelectorAll("a[href^='http']");
    return links.length ? links[0] : null;
  }

  function setLogo(iconEl, host){
    var img = iconEl.querySelector("img.brand-logo");
    if(!img) return;
    if(img.getAttribute("src")) {
      iconEl.classList.add("has-logo");
      return;
    }
        var ticker = img.getAttribute("data-ticker") || "";
        var emoji = img.getAttribute("data-emoji") || "⭐";

    var providers = [
      "https://" + host + "/favicon.ico",
      "https://" + host + "/icon.ico",
      "https://icons.duckduckgo.com/ip3/" + host + ".ico",
      "https://www.google.com/s2/favicons?domain=" + host + "&sz=128",
      "https://icons.google.com/favicon?domain=" + host + "&sz=128"
    ];
        if (ticker) {
      providers.push("https://github.io" + ticker + ".svg");
    }
    var idx = 0;
    img.loading = "lazy";
    img.decoding = "async";
    img.referrerPolicy = "no-referrer";

    function tryNext(){
            if(idx >= providers.length) {
        img.style.display = "none";
        var emojiNode = iconEl.querySelector('.emoji');
        if (!emojiNode) {
          emojiNode = document.createElement('span');
          emojiNode.className = 'emoji';
          emojiNode.innerText = emoji;
          iconEl.appendChild(emojiNode);
        }
        emojiNode.style.display = "inline-block";
        return;
      }

      img.src = providers[idx++];
    }

    img.addEventListener("load", function(){
      if (img.naturalWidth && img.naturalWidth >= 16) {
        iconEl.classList.add("has-logo");
      } else {
        tryNext();
      }
    }, {once:false});

    img.addEventListener("error", function(){
      tryNext();
    }, {once:false});

    tryNext();
  }

  document.addEventListener("DOMContentLoaded", function(){
    window.initAutoLogos = function() {
      var icons = document.querySelectorAll(".ecard-icon");
      icons.forEach(function(icon){
        var card = icon.closest(".ecard");
        if(!card) return;
        var a = firstOutboundLink(card);
        if(!a) return;
        var host = getHost(a.getAttribute("href"));
        if(!host) return;
        setLogo(icon, host);
      });
    };
    window.initAutoLogos();
  });
})();   